/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Student;
import util.ConnectionToDB;

/**
 *
 * @author cyusa
 */
public class StudentDao extends ConnectionToDB{
    public void saveStud(Student st){
        try {
            getConnection();
            ps=con.prepareStatement("insert into student values(?,?);");
            ps.setInt(1, st.getId());
            ps.setString(2, st.getName());
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            getDisconnetion();
        }
    }
}
