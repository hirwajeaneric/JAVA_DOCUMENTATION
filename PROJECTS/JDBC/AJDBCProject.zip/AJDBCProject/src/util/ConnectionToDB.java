/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cyusa
 */
public class ConnectionToDB {
    public Connection con=null;
    public Statement s=null;
    public PreparedStatement ps=null;
    public ResultSet rs=null;
    
    public void getConnection() {
        try {
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Student", "root", "");
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionToDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void getDisconnetion(){
        if(con!=null){
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionToDB.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(ps!=null){
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionToDB.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(rs!=null){
            try {
                rs.close();
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionToDB.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(s!=null){
            try {
                s.close();
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionToDB.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
