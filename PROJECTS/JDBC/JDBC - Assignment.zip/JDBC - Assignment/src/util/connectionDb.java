/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author seka
 */
public class connectionDb {
    public Connection con = null;
    public ResultSet rs = null;
    public PreparedStatement ps = null;
    public Statement s = null;
    public void getConnection(){ 
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root","");
            System.out.println("Connected");
        } catch (SQLException ex) {
            Logger.getLogger(connectionDb.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void getDisconnection(){
        
            try {
                if(con!=null){
                con.close();
                }
                if(rs!=null){
                    rs.close();
                }
                if(ps!=null){
                    ps.close();
                }
                if(s!=null){
                    s.close();
                }
                System.out.println("Disconnected");
            } catch (SQLException ex) {
                Logger.getLogger(connectionDb.class.getName()).log(Level.SEVERE, null, ex);
            }
            
    }
    
}
