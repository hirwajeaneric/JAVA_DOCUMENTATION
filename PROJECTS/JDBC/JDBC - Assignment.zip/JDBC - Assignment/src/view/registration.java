/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.departmentDao;
import controller.staffDao;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.department;
import model.staff;
import util.connectionDb;

/**
 *
 * @author seka
 */
public final class registration extends javax.swing.JInternalFrame {

    /**
     * Creates new form registration
     */
    departmentDao dao=new departmentDao();
    staffDao sao = new staffDao();
    department d = new department();
    public Connection con = null;
    public ResultSet rs = null;
    public PreparedStatement ps = null;
    public Statement s = null;
	
   public registration() {
        initComponents();
        updateDb();
        comb();
        updateTableStaff();

    }
   
   
    public void updateDb(){
        int q, i;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root","");
            s = con.createStatement();
            String sql = "SELECT * FROM department";
            rs = s.executeQuery(sql);
            ResultSetMetaData stData = rs.getMetaData();
            q = stData.getColumnCount();
            DefaultTableModel record = (DefaultTableModel) departTable.getModel();
            record.setRowCount(0);
            while(rs.next()){
                Vector columnData = new Vector();
                for (i = 1;  i<= q; i++) {
                    columnData.add(rs.getString("code"));
                    columnData.add(rs.getString("name"));
                    columnData.add(rs.getString("manager_id"));
                    
                    
                }
                record.addRow(columnData);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void updateTableStaff(){
        int q, i;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root","");
            s = con.createStatement();
            String sql = "SELECT * FROM staff";
            rs = s.executeQuery(sql);
            ResultSetMetaData stData = rs.getMetaData();
            q = stData.getColumnCount();
            DefaultTableModel record = (DefaultTableModel) jTable1.getModel();
            record.setRowCount(0);
            while(rs.next()){
                Vector columnData = new Vector();
                for (i = 1;  i<= q; i++) {
                    columnData.add(rs.getString("staff_id"));
                    columnData.add(rs.getString("names"));
                    columnData.add(rs.getString("dateOfBirth"));
                    columnData.add(rs.getInt("nationalId"));
                    columnData.add(rs.getString("phoneNumber"));
                    columnData.add(rs.getString("emailAddress"));
                    columnData.add(rs.getString("department_code"));
                    columnData.add(rs.getInt("supervisor_id"));
                    columnData.add(rs.getString("gender"));
                    
                    
                }
                record.addRow(columnData);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void comb() {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root","");
            //s = con.createStatement();
            String sql = "SELECT name FROM department";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                String name = rs.getString("name");
                //jComboBox1.addItem(name);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public String combSelect(String nam) {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root","");
            //s = con.createStatement();
            ps = con.prepareStatement("select code from staff where name=?");
            ps.setString(1, nam);
            ps.executeUpdate();
            String coded = rs.getString("code");
            jTextField7.setText(nam);
            return coded;
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return null;
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        btnSaveStaff = new javax.swing.JButton();
        cboxGender = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        updatStaff = new javax.swing.JButton();
        jTextField7 = new javax.swing.JTextField();
        delStaff = new javax.swing.JButton();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        dcode = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        dname = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        dmanage = new javax.swing.JTextField();
        btnSave = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        departTable = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDel = new javax.swing.JButton();

        jLabel4.setText("Enter Name");

        jLabel5.setText("Date Of Birth");

        jLabel6.setText("National ID");

        jLabel7.setText("Phone Number");

        jLabel8.setText("email address");

        jLabel9.setText("department");

        jLabel10.setText("Supervisor");

        jLabel11.setText("Gender");

        btnSaveStaff.setText("Save");
        btnSaveStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveStaffActionPerformed(evt);
            }
        });

        cboxGender.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Male", "Female", " ", " " }));
        cboxGender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboxGenderActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "NAME", "DOB", "NID", "PHONE", "EMAIL", "DEPARTMENT", "SUPERVISOR", "GENDER"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        updatStaff.setText("Update");
        updatStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatStaffActionPerformed(evt);
            }
        });

        delStaff.setText("Delete");
        delStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delStaffActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField1)
                            .addComponent(jTextField3)
                            .addComponent(jTextField4)
                            .addComponent(jTextField5)
                            .addComponent(jTextField6)
                            .addComponent(cboxGender, 0, 85, Short.MAX_VALUE)
                            .addComponent(jTextField7)
                            .addComponent(jDateChooser2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 584, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 14, Short.MAX_VALUE)
                        .addComponent(btnSaveStaff)
                        .addGap(18, 18, 18)
                        .addComponent(updatStaff)
                        .addGap(18, 18, 18)
                        .addComponent(delStaff)
                        .addGap(588, 588, 588))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(cboxGender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSaveStaff)
                    .addComponent(updatStaff)
                    .addComponent(delStaff))
                .addContainerGap(73, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("                       STAFF", jPanel1);

        jLabel1.setText("Department Code");

        jLabel2.setText("Department Name");

        jLabel3.setText("Manager");

        btnSave.setText("Save");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        departTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "code", "name", "manager"
            }
        ));
        departTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                departTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(departTable);

        jButton3.setText("exit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnDel.setText("Delete");
        btnDel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2))
                                .addGap(53, 53, 53))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3)
                                .addGap(112, 112, 112)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(dcode)
                            .addComponent(dname)
                            .addComponent(dmanage, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(29, Short.MAX_VALUE)
                        .addComponent(btnSave, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnUpdate)
                        .addGap(18, 18, 18)
                        .addComponent(btnDel)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3)
                        .addGap(35, 35, 35)))
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(228, 228, 228))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(dcode, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(dname, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(37, 37, 37)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(dmanage, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(219, 219, 219)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3)
                            .addComponent(btnDel)
                            .addComponent(btnUpdate)
                            .addComponent(btnSave)))))
        );

        jTabbedPane1.addTab("       DEPARTMENT", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        // TODO add your handling code here:
        String id = dcode.getText();
        String name = dname.getText();
        String manage = dmanage.getText();
        int manager = Integer.parseInt(manage);
        department d = new department();
        d.setCode(id);
        d.setName(name);
        d.setManager(manager);
        dao.saveDepartment(d);
        JOptionPane.showMessageDialog(this, "Department Record Added");
        updateDb();
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnSaveStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveStaffActionPerformed
        // TODO add your handling code here:
        //String staffid = jTextField8.getText();
        String name = jTextField1.getText();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dob =  sdf.format(jDateChooser2.getDate());
        String id = jTextField3.getText();
        String phone = jTextField4.getText();
        String email = jTextField5.getText();
        String department = jTextField7.getText();
        String superv = jTextField6.getText();                
        String gender = (String) cboxGender.getSelectedItem();
        int national = Integer.parseInt(id);
        int supervisor = Integer.parseInt(superv);
        staff s = new staff();
        s.setNames(name);
        s.setDob(dob);
        s.setNid(national);
        s.setPhone(phone);
        s.setEmail(email);
        s.setDepartment(department);
        s.setSupervisor(supervisor);
        s.setGender(gender);
        sao.saveStaff(s);
        JOptionPane.showMessageDialog(this, "Staff Record Added");
        updateTableStaff();
    }//GEN-LAST:event_btnSaveStaffActionPerformed
    private JFrame frame;
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        frame = new JFrame("Exit");
        if (JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit","Employee", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION){
            System.exit(0);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void departTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_departTableMouseClicked
        // TODO add your handling code here:
        DefaultTableModel recorded = (DefaultTableModel) departTable.getModel();
        int SelectedRows = departTable.getSelectedRow();
        
        dcode.setText(recorded.getValueAt(SelectedRows, 0).toString());
        dname.setText(recorded.getValueAt(SelectedRows, 1).toString());
        dmanage.setText(recorded.getValueAt(SelectedRows, 2).toString());
        
    }//GEN-LAST:event_departTableMouseClicked

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        // TODO add your handling code here:
        DefaultTableModel recorded = (DefaultTableModel) departTable.getModel();
        int SelectedRows = departTable.getSelectedRow();
        String pass = recorded.getValueAt(SelectedRows, 0).toString();
        String id = dcode.getText();
        String name = dname.getText();
        String manage = dmanage.getText();
        int manager = Integer.parseInt(manage);
        department d = new department();
        d.setCode(id);
        d.setName(name);
        d.setManager(manager);
        dao.updateDepartment(d, pass);
        JOptionPane.showMessageDialog(this, "Department Record Updated");
        updateDb();
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelActionPerformed
        DefaultTableModel recorded = (DefaultTableModel) departTable.getModel();
        int SelectedRows = departTable.getSelectedRow();
        String pass = recorded.getValueAt(SelectedRows, 0).toString();
        int deleteItem = JOptionPane.showConfirmDialog(null, "Confirm if you want to delete item","Warning",JOptionPane.YES_NO_OPTION);
        if(deleteItem == JOptionPane.YES_OPTION){
            dao.deleteDepartment(d, pass);
            JOptionPane.showMessageDialog(this, "Department Record Deleted");
            updateDb();
            dcode.setText("");
            dname.setText("");
            dmanage.setText("");
             
        }
        
    }//GEN-LAST:event_btnDelActionPerformed

    private void cboxGenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboxGenderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboxGenderActionPerformed

    private void updatStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatStaffActionPerformed
        // TODO add your handling code here:
        DefaultTableModel recorded = (DefaultTableModel) jTable1.getModel();
        int SelectedRows = jTable1.getSelectedRow();
        String pass = recorded.getValueAt(SelectedRows, 0).toString();
        String name = jTextField1.getText();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dob =  sdf.format(jDateChooser2.getDate());
        String nid = jTextField3.getText();
        String phone = jTextField4.getText();
        String email = jTextField5.getText();
        String depart = jTextField7.getText();
        String superv = jTextField6.getText();
        String gender = (String) cboxGender.getSelectedItem();
        int natinal = Integer.parseInt(nid);
        int supervisor = Integer.parseInt(superv);
        staff s = new staff();
        s.setNames(name);
        s.setDob(dob);
        s.setNid(natinal);
        s.setPhone(phone);
        s.setEmail(email);
        s.setDepartment(depart);
        s.setSupervisor(supervisor);
        s.setGender(gender);
        sao.updateStaff(s, pass);
        JOptionPane.showMessageDialog(this, "Staff Record Updated");
        updateTableStaff();
        
    }//GEN-LAST:event_updatStaffActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        DefaultTableModel recorded = (DefaultTableModel) jTable1.getModel();
        int SelectedRows = jTable1.getSelectedRow();
        
        jTextField1.setText(recorded.getValueAt(SelectedRows, 1).toString());
        
        try {
            java.util.Date dat;
            dat = new SimpleDateFormat("yyyy-MM-dd").parse((String) recorded.getValueAt(SelectedRows, 2));
            jDateChooser2.setDate(dat);
        } catch (ParseException ex) {
            Logger.getLogger(registration.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        jTextField3.setText(recorded.getValueAt(SelectedRows, 3).toString());
        jTextField4.setText(recorded.getValueAt(SelectedRows, 4).toString());
        jTextField5.setText(recorded.getValueAt(SelectedRows, 5).toString());
        jTextField7.setText(recorded.getValueAt(SelectedRows, 6).toString());
        jTextField6.setText(recorded.getValueAt(SelectedRows, 7).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void delStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delStaffActionPerformed
        // TODO add your handling code here:
        DefaultTableModel recorded = (DefaultTableModel) jTable1.getModel();
        int SelectedRows = jTable1.getSelectedRow();
        staff s = new staff();
        String pass = recorded.getValueAt(SelectedRows, 0).toString();
        int deleteItem = JOptionPane.showConfirmDialog(null, "Confirm if you want to delete item","Warning",JOptionPane.YES_NO_OPTION);
        if(deleteItem == JOptionPane.YES_OPTION){
            sao.deletStaff(s, pass);
            JOptionPane.showMessageDialog(this, "Staff Record Deleted");
            updateTableStaff();
            jTextField1.setText("");
            jDateChooser2.setDate(null);
            jTextField3.setText("");
            jTextField4.setText("");
            jTextField5.setText("");
            jTextField6.setText("");
            jTextField7.setText("");
            cboxGender.removeAll();
             
        }
    }//GEN-LAST:event_delStaffActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDel;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnSaveStaff;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox cboxGender;
    private javax.swing.JTextField dcode;
    private javax.swing.JButton delStaff;
    private javax.swing.JTable departTable;
    private javax.swing.JTextField dmanage;
    private javax.swing.JTextField dname;
    private javax.swing.JButton jButton3;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JButton updatStaff;
    // End of variables declaration//GEN-END:variables
}
