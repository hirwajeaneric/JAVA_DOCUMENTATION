/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author seka
 */
public class staff {
    private int id;
    private String names;
    private String dob;
    private int nid;
    private String phone;
    private String email;
    private String department;
    private int supervisor;
    private String gender;

    public staff() {
    }

    public staff(int id, String names, String dob, int nid, String phone, String email, String department, int supervisor, String gender) {
        this.id = id;
        this.names = names;
        this.dob = dob;
        this.nid = nid;
        this.phone = phone;
        this.email = email;
        this.department = department;
        this.supervisor = supervisor;
        this.gender = gender;
    }
    
    public void setId(){
        this.id=id;
    }
    
    public void setNames(String names) {
        this.names = names;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public void setNid(int nid) {
        this.nid = nid;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setSupervisor(int supervisor) {
        this.supervisor = supervisor;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    public String getNames() {
        return names;
    }

    public String getDob() {
        return dob;
    }

    public int getNid() {
        return nid;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getDepartment() {
        return department;
    }

    public int getSupervisor() {
        return supervisor;
    }

    public String getGender() {
        return gender;
    }

    public int getid() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
    
   
    
    
    
}
