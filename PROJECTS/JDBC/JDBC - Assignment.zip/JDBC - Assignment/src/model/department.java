/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author seka
 */
public class department {
    private String code;
    private String name;
    private int manager;

    public department() {
    }

    public department(String code, String name, int manager) {
        this.code = code;
        this.name = name;
        this.manager = manager;
    }
    
    public void setCode(String code) {
        this.code = code;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setManager(int manager) {
        this.manager = manager;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public int getManager() {
        return manager;
    }

    
    
}
