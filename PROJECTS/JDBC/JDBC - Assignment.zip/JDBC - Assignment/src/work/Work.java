/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package work;

import controller.staffDao;
import java.sql.Date;
import java.text.SimpleDateFormat;
import model.staff;

/**
 *
 * @author seka
 */
public class Work {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //department d = new department("r","software",0);
        //departmentDao y = new departmentDao();
        //y.saveDepartment(d);
        staff s = new staff();
        staffDao st = new staffDao();
        st.saveStaff(s);
        
        
    }
    
}
