/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.department;
import util.connectionDb;

/**
 *
 * @author seka
 */
public class departmentDao extends connectionDb {
    public void saveDepartment(department d){
        getConnection();
        try {
            ps = con.prepareStatement("insert into department values(?,?,?);");
            ps.setString(1, d.getCode());
            ps.setString(2, d.getName());
            ps.setInt(3, d.getManager());
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(departmentDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            getDisconnection();
        }
        
    }
    public void updateDepartment(department d,String id){
        getConnection();
        try {
            ps = con.prepareStatement("update department set code=?,name=?,manager_id=? where code=?");
            ps.setString(1, d.getCode());
            ps.setString(2, d.getName());
            ps.setInt(3, d.getManager());
            ps.setString(4, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }
    public void deleteDepartment(department d, String id){
        getConnection();
        try {
            ps = con.prepareStatement("delete from department where code=?");
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }
   
   public List<department> listDepartment(){
       List<department> depart = new ArrayList<>();
        try {
            s = con.createStatement();
             ResultSetMetaData stData = rs.getMetaData();
            String sql = "SELECT * FROM department";
            rs = s.executeQuery(sql);
            while(rs.next()){
                department d = new department();
                d.setCode(rs.getString(1));
                d.setName(rs.getString(2));
                d.setManager(rs.getInt(3));
                depart.add(d);
            }
        } catch (SQLException ex) {
            Logger.getLogger(departmentDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            getDisconnection();
        }
       return depart;
   }
}
    
