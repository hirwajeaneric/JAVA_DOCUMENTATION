/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.department;
import model.staff;
import util.connectionDb;

/**
 *
 * @author seka
 */
public class staffDao extends connectionDb {
    public void saveStaff(staff s){
        getConnection();
        try {
            ps = con.prepareStatement("insert into staff values(?,?,?,?,?,?,?,?,?);");
            ps.setInt(1, s.getid());
            ps.setString(1, s.getNames());
            ps.setString(2, s.getDob());
            ps.setInt(3, s.getNid());
            ps.setString(4, s.getPhone());
            ps.setString(5, s.getEmail());
            ps.setString(6, s.getDepartment());
            ps.setInt(7, s.getSupervisor());
            ps.setString(8, s.getGender());
            ps.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(staffDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public void updateStaff(staff s,String id){
        getConnection();
        try {
            ps = con.prepareStatement("update staff set names=?,dateOfBirth=?,nationalId=?,phoneNumber=?,emailAddress=?,department_code=?,supervisor_id=?,gender=? where staff_id=?");
            ps.setString(1, s.getNames());
            ps.setString(2, s.getDob());
            ps.setInt(3, s.getNid());
            ps.setString(4, s.getPhone());
            ps.setString(5, s.getEmail());
            ps.setString(6, s.getDepartment());
            ps.setInt(7, s.getSupervisor());
            ps.setString(8, s.getGender());
            ps.setString(9, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }
    public void deletStaff(staff s, String id){
        getConnection();
        try {
            ps = con.prepareStatement("delete from staff where staff_id=?");
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }
    
}
