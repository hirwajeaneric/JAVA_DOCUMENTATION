package chat_server;

import java.io.*;
import java.net.*;
import java.util.*;

public class server_frame extends javax.swing.JFrame {

    ArrayList clientOutputStreams;
    ArrayList<String> users;

    public class ClientHandler implements Runnable {

        BufferedReader reader;
        Socket sock;
        PrintWriter client;

        public ClientHandler(Socket clientSocket, PrintWriter user) {
            client = user;
            try {
                sock = clientSocket;
                InputStreamReader isReader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(isReader);
            } catch (Exception ex) {
                serverTextArea.append("Unexpected error... \n");
            }

        }

        @Override
        public void run() {
            String message, connect = "Connect", disconnect = "Disconnect", chat = "Chat", privatemsg = "private";
            String[] data;

            try {
                while ((message = reader.readLine()) != null) {
                    serverTextArea.append("Received: " + message + "\n");
                    data = message.split(":");

                    for (String token : data) {
                        serverTextArea.append(token + "\n");
                    }

                    if (data[2].equals(connect)) {
                        tellEveryone((data[0] + ":" + data[1] + ":" + chat));
                        userAdd(data[0]);
                    } else if (data[2].equals(disconnect)) {
                        tellEveryone((data[0] + ":has disconnected." + ":" + chat));
                        userRemove(data[0]);
                    } else if (data[2].equals(chat)) {
                        tellEveryone(message);
                    } else if (data[2].equals(privatemsg)) {

                        int recievedID = getid(data[3]);
                        // JOptionPane.showMessageDialog(null, ""+recievedID);
                        if (recievedID != -1) {
                            tellthispersononly(message, recievedID, data[3]);
                        } else {
                            tellthispersononly(message, recievedID, data[0]);
                        }

                    } else if (data[2].equals("request")) {

                        int recievedID;
                        // JOptionPane.showMessageDialog(null, "I am here ");
                        StringBuilder stringBuilder = new StringBuilder();
                        // stringBuilder.append("\n Online users ; \n");
                        // stringBuilder.append(" ONLINE USERS ; ");
                        for (String current_user : users) {
                            recievedID = getid(current_user);
                            System.out.println(recievedID);
                            stringBuilder.append(current_user).append(", With ID = ").append(recievedID);
                            // stringBuilder.append("\n");
                            stringBuilder.append(".   ");
                        }
                        recievedID = getid(data[0]);
                        String finalString = stringBuilder.toString();
                        finalString = data[0] + ":" + finalString + ":" + "request";
                        tellthispersononly(finalString, recievedID, data[0]); // d[0] here is the reciever person which
                        // is the in this case the sender itself
                        // JOptionPane.showMessageDialog(null, "I am here ,,,,, " + finalString);
                    } else {
                        serverTextArea.append("No Conditions were met. \n");
                    }
                }
            } catch (Exception ex) {
                serverTextArea.append("Lost a connection. \n");
                ex.printStackTrace();
                clientOutputStreams.remove(client);
            }
        }

    }

    public server_frame() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        serverTextArea = new javax.swing.JTextArea();
        startButton = new javax.swing.JButton();
        endButton = new javax.swing.JButton();
        onlineUsersButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chat - Server's frame");
        setName("server"); // NOI18N
        setResizable(false);

        serverTextArea.setColumns(20);
        serverTextArea.setRows(5);
        jScrollPane1.setViewportView(serverTextArea);

        startButton.setText("START");
        startButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startButtonActionPerformed(evt);
            }
        });

        endButton.setText("END");
        endButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endButtonActionPerformed(evt);
            }
        });

        onlineUsersButton.setText("Online Users");
        onlineUsersButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onlineUsersButtonActionPerformed(evt);
            }
        });

        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(endButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(startButton, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(clearButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(onlineUsersButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(startButton)
                    .addComponent(onlineUsersButton))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clearButton)
                    .addComponent(endButton))
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void endButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endButtonActionPerformed
        try {
            Thread.sleep(5000);                 //5000 milliseconds is five second.
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }

        tellEveryone("Server:is stopping and all users will be disconnected.\n:Chat");
        serverTextArea.append("Server stopping... \n");

        serverTextArea.setText("");
    }//GEN-LAST:event_endButtonActionPerformed

    private void startButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startButtonActionPerformed
        Thread starter = new Thread(new ServerStart());
        starter.start();

        serverTextArea.append("Server started...\n");
    }//GEN-LAST:event_startButtonActionPerformed

    private void onlineUsersButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_onlineUsersButtonActionPerformed
        serverTextArea.append("\n Online users : \n");
        for (String current_user : users) {
            serverTextArea.append(current_user);
            serverTextArea.append("\n");
        }

    }//GEN-LAST:event_onlineUsersButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        serverTextArea.setText("");
    }//GEN-LAST:event_clearButtonActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new server_frame().setVisible(true);
            }
        });
    }

    public class ServerStart implements Runnable {

        @Override
        public void run() {
            clientOutputStreams = new ArrayList();
            users = new ArrayList();

            try {
                ServerSocket serverSock = new ServerSocket(2222);

                while (true) {
                    Socket clientSock = serverSock.accept();
                    PrintWriter writer = new PrintWriter(clientSock.getOutputStream());
                    clientOutputStreams.add(writer);

                    Thread listener = new Thread(new ClientHandler(clientSock, writer));
                    listener.start();
                    serverTextArea.append("Got a connection. \n");
                }
            } catch (Exception ex) {
                serverTextArea.append("Error making a connection. \n");
            }
        }
    }

    public void userAdd(String data) {
        String message, add = ": :Connect", done = "Server: :Done", name = data;
        serverTextArea.append("Before " + name + " added. \n");
        users.add(name);
        serverTextArea.append("After " + name + " added. \n");
        String[] tempList = new String[(users.size())];
        users.toArray(tempList);

        for (String token : tempList) {
            message = (token + add);
            tellEveryone(message);
        }
        tellEveryone(done);
    }

    public void userRemove(String data) {
        String message, add = ": :Connect", done = "Server: :Done", name = data;
        users.remove(name);
        String[] tempList = new String[(users.size())];
        users.toArray(tempList);

        for (String token : tempList) {
            message = (token + add);
            tellEveryone(message);
        }
        tellEveryone(done);
    }

    public void tellEveryone(String message) {
        Iterator it = clientOutputStreams.iterator();

        while (it.hasNext()) {
            try {
                PrintWriter writer = (PrintWriter) it.next();
                writer.println(message);
                serverTextArea.append("Sending: " + message + "\n");
                writer.flush();
                serverTextArea.setCaretPosition(serverTextArea.getDocument().getLength());

            } catch (Exception ex) {
                serverTextArea.append("Error telling everyone. \n");
            }
        }
    }

    public int getid(String data) {

        int userid = users.indexOf(data);
        // JOptionPane.showMessageDialog(null, "the name is : "+data+ ", his ID is :
        // "+userid);
        return userid;
    }

    public void tellthispersononly(String msg, int personid, String recievername) {

        if (personid == -1) {

            msg = "The Server ... : The User is Not Found in the online users your message has not been deliverd  :private";
//		tellthispersononly(Errormsg, getid(data[0]), data[0]);
//		//JOptionPane.showMessageDialog(null, "No Name of the online users matches this name : "+ data[3] +"\n Check the online users correctly ", "This user is not found or not online", JOptionPane.ERROR_MESSAGE);
            personid = getid(recievername);
            try {
                PrintWriter writer = (PrintWriter) clientOutputStreams.get(personid); // (PrintWriter) it.next();
                writer.println(msg);
                writer.flush();
                serverTextArea.append("Sending to {" + recievername
                        + "} only this msg : Message not sent because the User not found in the online Users \n");
                serverTextArea.setCaretPosition(serverTextArea.getDocument().getLength());
            } catch (Exception ex) {
                serverTextArea.append("Error in telling this to " + recievername + "." + "\n");
            }

        } else {

            if (clientOutputStreams.get(personid) != null) {

                try {
                    PrintWriter writer = (PrintWriter) clientOutputStreams.get(personid); // clientOutputStreams[personid];
                    // //(PrintWriter) it.next();
                    writer.println(msg);
                    writer.flush();
                    serverTextArea.append("Sending to {" + recievername + "} only this msg :  " + msg + "\n");
                    serverTextArea.setCaretPosition(serverTextArea.getDocument().getLength());
                } catch (Exception ex) {
                    serverTextArea.append("Error in telling this " + recievername + "." + "\n");
                }
            } else {
                serverTextArea.append("Error in telling this ... his ID not found OR His outputstream is null " + recievername
                        + "." + "\n");
            }
        }
    }

    //--------------------------//
    public void writeUsers() {
        String[] tempList = new String[(users.size())];
        users.toArray(tempList);
        for (String token : tempList) {
            //users.append(token + "\n");
        }
    }

    //--------------------------//
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton clearButton;
    private javax.swing.JButton endButton;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton onlineUsersButton;
    private javax.swing.JTextArea serverTextArea;
    private javax.swing.JButton startButton;
    // End of variables declaration//GEN-END:variables
}
