/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author The flash
 */
public class server {
    private static ServerSocket serversocket;
    private static Socket socket;
    private static int PORT = 2104;
    private static ArrayList<clientHandler> clients = new ArrayList();
    private static ExecutorService pool = Executors.newFixedThreadPool(4);

    public server() {
        super();
    }
    
    public static void main(String[] args) {
        try {
            serversocket = new ServerSocket(PORT);
            while(true){
                System.out.println("Server wait for connection ....");
                socket = serversocket.accept();
                System.out.println("Client connected !!");
                clientHandler clientThread = new clientHandler(socket, clients);
                clients.add(clientThread);
                pool.execute(clientThread);
            }
        } catch (IOException ex) {
            Logger.getLogger(server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
