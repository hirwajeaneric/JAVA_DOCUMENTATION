/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;

/**
 *
 * @author The flash
 */
public class clientHandler implements Runnable{
    private Socket socket;
    private ArrayList<clientHandler> clients;
    private static ArrayList names = new ArrayList();
    private ObjectInputStream ois;
    private ObjectOutputStream oos;
    public clientHandler(Socket socket, ArrayList<clientHandler> clients) {
        this.socket = socket;
        this.clients = clients;
    }

    @Override
    public void run() {
        try {
            ois = new ObjectInputStream(socket.getInputStream());
            oos = new ObjectOutputStream(socket.getOutputStream());
            while(true){
                if(ois == null)
                    break;
                DefaultListModel model = (DefaultListModel) ois.readObject();
                String request = (String) model.getElementAt(0);
                System.out.println(request);
                if(request.equals("SEND_NAME")){
                    String name = (String) model.getElementAt(1);
                    System.out.println(name);
                    names.add(name);
                }
                if(request.equals("SEND_MESSAGE"))
                    {
                        String msg = (String) model.getElementAt(1);
                        String receiver = (String) model.getElementAt(2);
                        sendMessageToOne(msg,receiver);
                    }
                if(request.equals("SEND_GROUP"))
                    {
                        String msg = (String) model.getElementAt(1);
                        String sender = (String) model.getElementAt(2);
                        sendMessageToGroup(msg,sender);
                    }
                if(request.equals("LOGOUT")){
                    String name = (String) model.getElementAt(1);
                    removeUser(name, this);
                }
                if(request.equals("SEND_NAMES")){
                    sendNames();
                }
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(clientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
                try {
                    ois.close();
                    oos.close();
                } catch (IOException ex) {
                    Logger.getLogger(clientHandler.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
    }

    private void sendMessageToOne(String msg, String receiver) throws IOException {
        int j=0;
        DefaultListModel model = new DefaultListModel();
        model.addElement("SEND_MESSAGE");
        model.addElement(msg);
        System.out.println("Server says > "+msg);
        for(clientHandler aClient:clients){
            if(names.get(j).equals(receiver)){
                System.out.println("Message sent To "+names.get(j));
                j=0;
                aClient.oos.writeObject(model);
                System.out.println("Message sent To one");
                oos.reset();
                break;
            }
            else
            {
                j++;
            }
        }
    }
    private void sendMessageToGroup(String msg,String sender) throws IOException {
        int j=0;
        DefaultListModel model = new DefaultListModel();
        model.addElement("SEND_GROUP");
        model.addElement(msg);
        for(clientHandler aClient:clients){
            if(names.get(j).equals(sender)){
                j++;
            }
            else
            {
                aClient.oos.writeObject(model);
                oos.reset();
                System.out.println("Message sent To group");
                j++;
            }
        }
    }
    private void removeUser(String name, clientHandler aUser) throws IOException {
        boolean removed = names.remove(name);
            if (removed) {
            clients.remove(aUser);
            System.out.println("The user " + name + " quitted");
            socket.close();
        }
    }
    private void sendNames() throws IOException{
        System.out.println("SendNames");
        DefaultListModel model = new DefaultListModel();
        model.addElement("SEND_NAMES");
        model.addElement(names);
        for(clientHandler c:clients)
            c.oos.writeObject(model);
        oos.reset();
    }
}
