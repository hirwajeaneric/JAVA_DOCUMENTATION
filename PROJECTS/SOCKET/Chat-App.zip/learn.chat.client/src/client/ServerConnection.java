/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.*;
import java.util.ArrayList;
import javax.swing.DefaultListModel;

/**
 *
 * @author The flash
 */
public class ServerConnection implements Runnable{
    private Socket server;
    private ObjectInputStream oin;

    public ServerConnection(Socket server) throws IOException {
        this.server = server;
    }
    
    
    @Override
    public void run() {
        
        try {
            oin = new ObjectInputStream(server.getInputStream());
            String serverResponse=null;
                while(true){
               DefaultListModel result = (DefaultListModel) oin.readObject();
                serverResponse = (String) result.getElementAt(0);
                if(serverResponse==null) 
                    break;
                else if(serverResponse.equals("SEND_MESSAGE")){
                    String msg = (String) result.getElementAt(1);
                    ClientView.CreateBoxMessage(msg, false);
                }
                else if(serverResponse.equals("SEND_GROUP")){
                    String msg = (String) result.getElementAt(1);
                    ClientView.CreateBoxMessage(msg,false);
                }else
                {
                    ArrayList names = (ArrayList) result.getElementAt(1);
                    ClientView.addUsers(names);
                }
                }
            } catch (IOException| ClassNotFoundException ex) {

            }
            
            finally{
                try {
                    oin.close();
                } catch (IOException ex) {
                    
                }

            }
    }
    
}
