/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sms.controller;

import sms.Model.Staff;
import sms.util.ConnectionToDB;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author hirwa
 */
public class StaffDao extends ConnectionToDB {
    public void saveStaff(Staff s){
        try {
            getConnection();
            ps = con.prepareStatement("INSERT INTO staff values (?,?,?,?,?,?,?,?)");
            ps.setString(1, s.getFirstName());
            ps.setString(2, s.getLastName());
            ps.setString(3, s.getStaffId());
            ps.setString(4, s.getNationalId());
            ps.setString(5, s.getDepartment());
            ps.setString(6, s.getPhoneNumber());
            ps.setString(7, s.getEmailAddress());
            ps.setString(8, s.getLocation());
            
            ps.executeUpdate();
            
        } catch (SQLException e) {
            Logger.getLogger(StaffDao.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            getDisconnection();
        }
    }
}
