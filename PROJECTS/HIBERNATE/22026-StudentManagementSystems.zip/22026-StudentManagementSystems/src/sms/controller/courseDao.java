/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sms.controller;

import sms.Model.Courses;
import sms.util.ConnectionToDB;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hirwa
 */
public class courseDao extends ConnectionToDB{
    public void saveCourse(Courses c){
        try {
            getConnection();
            ps = con.prepareStatement("INSERT INTO courses values (?,?,?,?)");
            ps.setString(1, c.getCourseId());
            ps.setString(2, c.getCourseName());
            ps.setString(3, c.getCredits());
            ps.setString(4, c.getSemester());
            
            ps.executeUpdate();
            
        } catch (SQLException e) {
            Logger.getLogger(courseDao.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            getDisconnection();
        }
    }
}
