/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sms.controller;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sms.util.ConnectionToDB;
import sms.Model.Student;

/**
 *
 * @author hirwa
 */
public class StudentDao extends ConnectionToDB {
    public void Savestudent(Student st){
        try {
            getConnection();
            ps = con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?)");
            ps.setString(1, st.getFirstName());
            ps.setString(2, st.getLastName());
            ps.setString(3, st.getRegNumber());
            ps.setString(4, st.getEmailAddress());
            ps.setString(5, st.getPhoneNumber());
            ps.setString(6, st.getNationalId());
            ps.setString(7, st.getGender());
            ps.setString(8, st.getFaculty());
            
            ps.executeUpdate();
            
        } catch (SQLException e) {
            Logger.getLogger(StudentDao.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            getDisconnection();
        }
    }
}
