/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sms.controller;
import sms.util.ConnectionToDB;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sms.Model.Signup;

/**
 *
 * @author hirwa
 */
public class SignupDao extends ConnectionToDB {
    public void SaveSignup(Signup si){
        try {
            getConnection();
            ps = con.prepareStatement("insert into signup values(?,?,?,?,?,?)");
            ps.setString(1, si.getFistname());
            ps.setString(2, si.getLastname());
            ps.setString(3, si.getEmailAddress());
            ps.setString(4, si.getUsername());
            ps.setString(5, si.getPassword1());
            ps.setString(6, si.getPassword2());
                    
            ps.executeUpdate();
        } catch (SQLException e) {
            Logger.getLogger(SignupDao.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            getDisconnection();
        }
    }
}
