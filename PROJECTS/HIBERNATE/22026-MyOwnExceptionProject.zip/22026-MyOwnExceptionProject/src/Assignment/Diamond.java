/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import javax.swing.JOptionPane;

/**
 *
 * @author hirwa
 */
public class Diamond {
    
    static void printDiamond(int size) {
        String diamond = "";
        /* print upper triangle */
        for (int r = 1, a = 1; r <= size; r++, a+=2) {
            /* print spaces */
            for (int i = size - r; i >= 1; i--) {
                diamond += " ";
            }
            /* print *'s */
            for (int j = 1; j <= a; j++) {
                diamond += "*";
            }
            diamond += "\n";
        }
        /* print lower triangle */
        for (int r = size - 1, a = 2*(size-1)-1; r >= 1; r--, a-=2) {
            /* print spaces */
            for (int i = size - r; i >= 1; i--) {
                diamond += " ";
            }
            /* print *'s */
            for (int j = 1; j <= a; j++) {
                diamond += "*";
            }
            diamond += "\n";
        }
        JOptionPane.showMessageDialog(null, diamond);
        System.out.println(diamond);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws MyOwnNegativeValueEnteredException, MyOwnZeroValueEnteredException {
        // TODO code application logic here
        String strSize;
       
        //My own exception.
        strSize = JOptionPane.showInputDialog(null, "Enter diamond size:");
        int size = Integer.parseInt(strSize);
        if(size < 0){
            throw new MyOwnNegativeValueEnteredException("You entered an invalid(negative) value "+ size +". Diamond size should be > 0");
        }else if(size == 0){
            throw new MyOwnZeroValueEnteredException("You entered invalid(zero) value "+ size + ". Diamond size can't be 0");
        }else{
            try{
               printDiamond(size);
            }catch(Exception e){
                System.out.println("Exception occured: ");
            }
        }
        
    }
}
    

