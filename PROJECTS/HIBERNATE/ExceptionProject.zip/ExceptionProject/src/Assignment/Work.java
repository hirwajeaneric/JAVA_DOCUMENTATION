package Assignment;

import javax.swing.JOptionPane;

public class Work {
    
    static void printDiamond(int size) {
        String diamond = "";
        /* print upper triangle */
        for (int r = 1, a = 1; r <= size; r++, a+=2) {
            /* print spaces */
            for (int i = size - r; i >= 1; i--) {
                diamond += " ";
            }
            /* print *'s */
            for (int j = 1; j <= a; j++) {
                diamond += "*";
            }
            diamond += "\n";
        }
        /* print lower triangle */
        for (int r = size - 1, a = 2*(size-1)-1; r >= 1; r--, a-=2) {
            /* print spaces */
            for (int i = size - r; i >= 1; i--) {
                diamond += " ";
            }
            /* print *'s */
            for (int j = 1; j <= a; j++) {
                diamond += "*";
            }
            diamond += "\n";
        }
        JOptionPane.showMessageDialog(null, diamond);
        System.out.println(diamond);
    }

    public static void main(String[] args) throws MyOwnNegativeValueEnteredException, MyOwnZeroValueEnteredException {

        String strSize;
        strSize = JOptionPane.showInputDialog(null, "Enter diamond size:");
        int size = Integer.parseInt(strSize);
        if(size < 0){
            throw new MyOwnNegativeValueEnteredException("The entered negative value "+ size + " is invalid. Size should be > 0");
        }else if(size == 0){
            throw new MyOwnZeroValueEnteredException("The entered zero value "+ size + " is invalid. Size should be > 0");
        }else{
            try{
               printDiamond(size);
            }catch(Exception e){
                System.out.println("Exception occured: ");
            }
        }
        
    }
}
    

