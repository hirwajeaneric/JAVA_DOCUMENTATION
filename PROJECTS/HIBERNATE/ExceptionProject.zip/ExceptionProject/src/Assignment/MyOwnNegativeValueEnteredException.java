package Assignment;

public class MyOwnNegativeValueEnteredException extends Exception {

    public MyOwnNegativeValueEnteredException(String string) {
        super(string);
    }
    
}
