package Assignment;

public class MyOwnZeroValueEnteredException extends Exception {

    public MyOwnZeroValueEnteredException(String string) {
        super(string);
    }
    
}
